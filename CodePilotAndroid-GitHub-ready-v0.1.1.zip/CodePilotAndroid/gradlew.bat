@echo off
setlocal
set "GRADLE_VERSION=8.9"
if "%GRADLE_USER_HOME%"=="" set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "DIST=%GRADLE_USER_HOME%\codepilot-distributions\gradle-%GRADLE_VERSION%"
set "ZIP=%GRADLE_USER_HOME%\codepilot-distributions\gradle-%GRADLE_VERSION%-bin.zip"
if not exist "%DIST%\bin\gradle.bat" (
  if not exist "%GRADLE_USER_HOME%\codepilot-distributions" mkdir "%GRADLE_USER_HOME%\codepilot-distributions"
  if not exist "%ZIP%" powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP%'"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP%' '%GRADLE_USER_HOME%\codepilot-distributions'"
)
call "%DIST%\bin\gradle.bat" -p "%~dp0" %*
exit /b %ERRORLEVEL%
