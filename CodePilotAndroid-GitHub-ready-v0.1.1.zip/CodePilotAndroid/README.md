# CodePilot Android

**Versión:** 0.1.1 · **Estado:** prototipo de código fuente, no versión de producción.

Aplicación Android nativa en Kotlin y Jetpack Compose para iniciar un asistente de programación desde el teléfono. Interfaz en español con Chat, Archivos, Terminal restringida y Ajustes.

## Funciones incluidas

- Interfaz oscura con navegación inferior.
- Selector de carpeta de proyecto mediante el selector de documentos de Android.
- Explorador de archivos de texto, editor y confirmación antes de guardar.
- Chat contra un endpoint compatible con OpenAI Chat Completions.
- Terminal experimental limitada a `pwd`, `ls`, `find` y `cat` dentro del espacio privado de la aplicación.
- Configuración Gradle Kotlin DSL y flujo de integración continua de GitHub Actions.

## Requisitos de compilación

- JDK 17.
- Android SDK Platform 35 y Build Tools compatibles.
- Gradle 8.9 (el script `gradlew` incluido descarga la distribución oficial si el entorno tiene Java, `curl`/`wget` y `unzip`; en Windows usa PowerShell).
- Conexión a Internet para descargar Gradle y dependencias.

El Gradle Wrapper oficial normalmente incluye `gradle-wrapper.jar`. Este repositorio usa un script de arranque ligero (`gradlew`/`gradlew.bat`) que descarga y ejecuta Gradle 8.9 para evitar depender de ese JAR ausente en el paquete original. Algunos IDE Android móviles pueden exigir el Wrapper estándar; si ocurre, usa Gradle instalado en el entorno o genera el wrapper estándar con `gradle wrapper --gradle-version 8.9`.

## Compilar

### Linux, macOS o entorno Android compatible

```sh
chmod +x gradlew
./gradlew assembleDebug
```

### Windows

```bat
gradlew.bat assembleDebug
```

El APK de depuración, si la compilación termina correctamente, se genera en `app/build/outputs/apk/debug/app-debug.apk`. El proyecto **no incluye un APK precompilado**. La primera compilación puede tardar y usar bastante almacenamiento.

## Abrir en GitHub

1. En GitHub crea un repositorio nuevo, por ejemplo `CodePilotAndroid`.
2. Descomprime este ZIP. En la raíz de la carpeta `CodePilotAndroid` están `README.md`, `settings.gradle.kts`, `build.gradle.kts`, `app/` y el resto de los archivos.
3. Sube el contenido de esa carpeta al repositorio (no subas la carpeta ZIP dentro del repositorio). Puedes usar la opción **Add file → Upload files** o Git desde un entorno compatible.
4. GitHub Actions ejecutará la compilación al hacer push o abrir un pull request. Si el trabajo termina bien, el APK de depuración quedará como artefacto de la ejecución.

## Configurar el chat

En Ajustes se configura la URL base del proveedor, el identificador de modelo y, si hace falta, una clave API. La aplicación agrega `/chat/completions` a la URL base. Usa solo proveedores de confianza. No guardes claves en el código ni las publiques en GitHub. En este prototipo la clave se guarda en preferencias privadas de la app sin cifrado; no se recomienda para secretos de alto valor.

## Limitaciones conocidas

- No se ha verificado en este entorno una compilación Android completa ni probado en un teléfono físico. El flujo de GitHub Actions sirve para efectuar esa verificación.
- No genera ni instala automáticamente parches propuestos por la IA.
- Git, pruebas del proyecto, ejecución de Gradle dentro de la app y compilación de APK desde la propia app todavía no están implementados.
- La terminal no es una terminal general y no ejecuta scripts arbitrarios.
- El endpoint local solo conecta con un servidor existente; no instala ni ejecuta un modelo local por sí solo.
- `usesCleartextTraffic` está habilitado para permitir pruebas con servidores HTTP locales. No envíes claves ni información sensible por HTTP; para uso real, prefiere HTTPS.

## Estructura principal

```text
CodePilotAndroid/
├── .github/workflows/android.yml
├── app/src/main/AndroidManifest.xml
├── app/src/main/java/com/example/codepilot/MainActivity.kt
├── app/build.gradle.kts
├── gradle/wrapper/gradle-wrapper.properties
├── build.gradle.kts
├── gradle.properties
├── settings.gradle.kts\├── gradlew
├── gradlew.bat
├── LICENSE
└── README.md
```

## Contribuciones y seguridad

Lee `SECURITY.md` antes de reportar vulnerabilidades. No incluyas claves API, tokens, datos personales, archivos de firma ni `local.properties` en incidencias o commits.
