# Seguridad

- No subas claves API, tokens, contraseñas, `local.properties`, keystores ni archivos de firma.
- La versión 0.1.1 es un prototipo; la clave API se guarda en preferencias privadas sin cifrado.
- Informa vulnerabilidades al mantenedor en privado antes de publicar detalles. No incluyas secretos reales en incidencias.
