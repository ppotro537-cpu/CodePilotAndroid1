---
name: Solicitud de mejora
about: Proponer una función
title: "[Mejora] "
labels: enhancement
assignees: ''
---

**Problema que resolvería**

**Solución propuesta**

**Alternativas consideradas**
