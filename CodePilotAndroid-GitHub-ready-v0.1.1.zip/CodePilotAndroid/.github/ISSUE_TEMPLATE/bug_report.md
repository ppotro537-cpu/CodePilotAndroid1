---
name: Reportar un error
about: Informar un problema reproducible
title: "[Error] "
labels: bug
assignees: ''
---

**Descripción**

**Pasos para reproducir**
1.
2.
3.

**Resultado esperado**

**Resultado obtenido**

**Dispositivo / versión de Android**

**Registro de compilación (sin claves ni datos personales)**
